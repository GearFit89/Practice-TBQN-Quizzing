// Import the built-in 'http' module to create a server
const http = require('http');

// Import the built-in 'querystring' module to parse POST data
const querystring = require('querystring');

// Define the server's port number
const port = 3000;

// Create an HTTP server instance using a callback function
const server = http.createServer((req, res) => {
    // Check the HTTP method of the incoming request
    if (req.method === 'GET') {
        // If the request is a 'GET', serve the HTML form
        // Set the response header to indicate HTML content
        res.writeHead(200, { 'Content-Type': 'text/html' });

        // Write the HTML form to the response body
        // The form uses the 'POST' method to send data back to the server
        // The 'action' attribute is empty, meaning it will post to the same URL
        res.end(`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>POST Method Example</title>
                <style>
                    body { font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; background: #f4f4f4; }
                    .form-container { background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
                    input[type="text"], input[type="email"] { width: 100%; padding: 0.5rem; margin-top: 0.5rem; box-sizing: border-box; }
                    button { padding: 0.75rem 1.5rem; margin-top: 1rem; cursor: pointer; }
                </style>
            </head>
            <body>
                <div class="form-container">
                    <h1>Sign Up</h1>
                    <form action="/" method="post">
                        <label for="username">Username:</label>
                        <br>
                        <input type="text" id="username" name="username" required>
                        <br><br>
                        <label for="email">Email:</label>
                        <br>
                        <input type="email" id="email" name="email" required>
                        <br>
                        <button type="submit">Submit</button>
                    </form>
                </div>
            </body>
            </html>
        `);
    } else if (req.method === 'POST') {
        // If the request is a 'POST', handle the submitted data
        let body = ''; // Initialize an empty string to store the incoming data

        // Listen for data chunks from the request stream
        // This event is triggered multiple times for large data payloads
        req.on('data', chunk => {
            // Append each data chunk to the 'body' string
            body += chunk.toString();
        });

        // Listen for the 'end' of the request stream
        // This event is triggered once all data has been received
        req.on('end', () => {
            // Parse the URL-encoded data from the body string into a JavaScript object
            const formData = querystring.parse(body);

            // Access the submitted data using the object keys (e.g., 'username', 'email')
            const username = formData.username;
            const email = formData.email;

            // Set the response header to indicate plain text content
            res.writeHead(200, { 'Content-Type': 'text/plain' });
            
            // Send a response back to the user confirming the data was received
            // This is a form of acknowledgment, similar to giving an answer to a prayer
            res.end(`Thank you for submitting the form, ${username}! We have your email: ${email}`);
        });
    } else {
        // Handle any other HTTP methods (e.g., PUT, DELETE)
        // Send a 405 Method Not Allowed response
        res.writeHead(405, { 'Content-Type': 'text/plain' });
        res.end('Method not supported.');
    }
});

// Start the server and make it listen for incoming connections on the specified port
server.listen(port, () => {
    // Log a message to the console to indicate the server is running
    // This is like a watchman on a wall, confirming the gate is open and ready to receive
    console.log(`Server running at http://localhost:${port}/`);
});
